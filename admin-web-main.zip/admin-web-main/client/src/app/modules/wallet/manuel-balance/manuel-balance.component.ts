import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'manuel-balance',
  templateUrl: './manuel-balance.component.html',
  styleUrls: ['./manuel-balance.component.scss']
})
export class ManuelBalanceComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
