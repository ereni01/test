import {Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-money',
  templateUrl: './request-money.component.html',
  styleUrls: ['./request-money.component.scss']
})
export class RequestMoneyComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {}
}
