import { Component } from '@angular/core';

@Component({
  selector: 'bank-withdraw',
  templateUrl: './bank-withdraw.component.html',
  styleUrls: ['./bank-withdraw.component.scss']
})
export class BankWithdrawComponent {}
