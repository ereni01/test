import { Component } from '@angular/core';

@Component({
  selector: 'card-deposit',
  templateUrl: './card-deposit.component.html',
  styleUrls: ['./card-deposit.component.scss']
})
export class CardDepositComponent {}
