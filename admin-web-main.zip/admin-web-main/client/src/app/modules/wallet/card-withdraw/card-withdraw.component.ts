import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'card-withdraw',
  templateUrl: './card-withdraw.component.html',
  styleUrls: ['./card-withdraw.component.scss']
})
export class CardWithdrawComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
