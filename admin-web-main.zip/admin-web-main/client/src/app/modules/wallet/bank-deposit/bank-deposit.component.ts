import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bank-deposit',
  templateUrl: './bank-deposit.component.html',
  styleUrls: ['./bank-deposit.component.scss']
})
export class BankDepositComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
