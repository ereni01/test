import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'merchant-accounting',
  templateUrl: './merchant-accounting.component.html',
  styleUrls: ['./merchant-accounting.component.scss']
})
export class MerchantAccountingComponent implements OnInit {
  ngOnInit(): void {}
}
