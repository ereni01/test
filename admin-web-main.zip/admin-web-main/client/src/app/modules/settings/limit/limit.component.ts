import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'limit',
  templateUrl: './limit.component.html',
  styleUrls: ['./limit.component.scss']
})
export class LimitComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
