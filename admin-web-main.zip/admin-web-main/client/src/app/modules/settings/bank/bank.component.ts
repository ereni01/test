import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.scss']
})
export class BankComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
