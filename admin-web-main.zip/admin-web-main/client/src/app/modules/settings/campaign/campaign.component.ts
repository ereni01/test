import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.scss']
})
export class CampaignComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
