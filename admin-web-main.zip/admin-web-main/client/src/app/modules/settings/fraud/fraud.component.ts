import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fraud',
  templateUrl: './fraud.component.html',
  styleUrls: ['./fraud.component.scss']
})
export class FraudComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
