import { Component } from "@angular/core";

@Component({
  selector: "app-bank-accounts",
  templateUrl: './bank-accounts.component.html',
  styleUrls: ['./bank-accounts.component.scss']
})

export class BankAccountsComponent{}
