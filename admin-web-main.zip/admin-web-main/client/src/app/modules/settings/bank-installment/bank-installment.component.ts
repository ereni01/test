import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bank-installment',
  templateUrl: './bank-installment.component.html',
  styleUrls: ['./bank-installment.component.scss']
})
export class BankInstallmentComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
