import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pos-bank',
  templateUrl: './pos-bank.component.html',
  styleUrls: ['./pos-bank.component.scss']
})
export class PosBankComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
