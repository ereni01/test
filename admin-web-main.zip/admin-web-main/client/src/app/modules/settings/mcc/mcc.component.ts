import { Component } from '@angular/core';

@Component({
  selector: 'mcc',
  templateUrl: './mcc.component.html',
  styleUrls: ['./mcc.component.scss']
})
export class MccComponent {}
