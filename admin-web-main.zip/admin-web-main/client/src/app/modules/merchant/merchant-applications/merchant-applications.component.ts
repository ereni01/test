import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-applications',
  template: '<router-outlet></router-outlet>'
})
export class MerchantApplicationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
