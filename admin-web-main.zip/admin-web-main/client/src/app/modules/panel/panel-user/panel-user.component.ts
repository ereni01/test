import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'panel-user',
  templateUrl: './panel-user.component.html',
  styleUrls: ['./panel-user.component.scss']
})
export class PanelUserComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
