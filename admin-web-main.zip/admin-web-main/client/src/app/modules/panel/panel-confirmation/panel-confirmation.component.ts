import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'panel-confirmation',
  templateUrl: './panel-confirmation.component.html',
  styleUrls: ['./panel-confirmation.component.scss']
})
export class PanelConfirmationComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
