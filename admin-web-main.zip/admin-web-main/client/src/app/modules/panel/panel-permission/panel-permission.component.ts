import { Component } from '@angular/core';

@Component({
  selector: 'panel-permission',
  templateUrl: './panel-permission.component.html',
  styleUrls: ['./panel-permission.component.scss']
})
export class PanelPermissionComponent {}
