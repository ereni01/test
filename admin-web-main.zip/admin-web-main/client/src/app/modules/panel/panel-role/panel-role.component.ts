import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'panel-role',
  templateUrl: './panel-role.component.html',
  styleUrls: ['./panel-role.component.scss']
})
export class PanelRoleComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
