import { Component } from '@angular/core';
import { SettingsService } from '@app/core/http';
@Component({
  selector: 'select-service',
  templateUrl: './select-service.component.html',
  styleUrls: ['./select-service.component.scss']
})
export class SelectServiceComponent {
  constructor() {


  }
}
