import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'public',
  templateUrl: './public.component.html',
  styleUrls: ['./public.component.scss']
})
export class PublicComponent implements OnInit {
  ngOnInit(): void {}
}
