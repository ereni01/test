export const systemConfig = {
  loginUrl: '/public/login',
  unauthorizedRedirectTo: '/public/login'
};
