export interface Login {
  username: string;
  password: string;
}
export interface LoginOut {
  access_token: string;
  full_name: string;
}
